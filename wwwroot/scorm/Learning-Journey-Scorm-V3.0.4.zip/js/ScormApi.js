var scorm = {};
var scormInitialized = false;

var version_2004 = false;

function InitializeLMS() {
    var limitRetry = 0;
    for (var win = window; win != null; win = win.parent) {
        limitRetry++;
        if (win.API) {
            console.log("Found SCORM Version 1.2");
            scorm.api = win.API;
            version_2004 = false;
            break;
        }
        if (win.API_1484_11) {
            console.log("Found SCORM Version 2004");
            scorm.api = win.API_1484_11;
            version_2004 = true;
            break;
        }

        if (win === window.top) {
            // Reached the top-level window, break to avoid an infinite loop  
            break;
        }
        if (limitRetry >= 100) {
            break;
        }
    }

    if (!scorm.api) {
        // check parents first. Check if there is a window that opens this (maybe scorm is in new TAB or POP-UP)
        console.log("SCORM API not found in current frame. Checking in Parent Window.");

        if (window.opener) {
            var limitRetry = 0;
            for (var win = window.opener; win != null; win = win.parent) {
                limitRetry++;
                if (win.API) {
                    console.log("Found SCORM Version 1.2");
                    scorm.api = win.API;
                    version_2004 = false;
                    break;
                }
                if (win.API_1484_11) {
                    console.log("Found SCORM Version 2004");
                    scorm.api = win.API_1484_11;
                    version_2004 = true;
                    break;
                }

                if (win === window.top) {
                    // Reached the top-level window, break to avoid an infinite loop  
                    break;
                }
                if (limitRetry >= 100) {
                    break;
                }
            }
        }
    }

    if (!scorm.api) {
        console.log("Scorm API Not Found!");
        return false;
    }

    var isScormInitialized = IsScormInitialized();
    if (isScormInitialized) {
        console.log("SCORM Already Initialized");
        scormInitialized = true;
        return scormInitialized;
    } else {
        if (scorm.api) {
            // bool true if initialized bool false if failed.
            scormInitialized = InitializeLmsProcess();
            if (!scormInitialized) {
                console.log("SCORM Failed to Initialize");
            } else {
                console.log("SCORM Initialized");
            }
            return scormInitialized;
        } else {
            // SCORM API not found.  
            console.log("SCORM API not found");
            return false;
        }
    }

}

function IsScormInitialized() {
    console.log("Checking for SCORM Initialize State");
    try {
        GetScore_CheckInitial();
        var errorCode = 0;
        if (scorm.api) {
            if (version_2004) {
                errorCode = scorm.api.GetLastError();
            } else {
                errorCode = scorm.api.LMSGetLastError();
            }
        } else {
            return false;
        }
        console.log("Last Error Code: " + errorCode);
        if (version_2004) {
            return errorCode != 122 || errorCode == 301;
        }
        else {
            return errorCode != 301; // 301 is error code if not initiliazed
        }

    } catch {
        return false;
    }

}

function InitializeLmsProcess() {
    console.log("SCORM: Initializing - Begin");

    if (scorm.api) {
        if (version_2004) {
            return scorm.api.Initialize("") == "true";
        } else {
            return scorm.api.LMSInitialize("") == "true";
        }
    }

    console.log("SCORM: Initializing - Result: " + "NOT INITIALIZED");
}

function SetScore(newScore) {
    console.log("SCORM: Set Score - Begin");
    var result = false;

    if (scorm.api && scormInitialized) {
        if (version_2004) {
            scorm.api.SetValue("cmi.score.min", 0);
            scorm.api.SetValue("cmi.score.max", 100);
            scorm.api.SetValue("cmi.score.raw", newScore)
            var apiResult = scorm.api.SetValue("cmi.score.scaled", newScore / 100)
            result = apiResult == "true";
        } else {
            var apiResult = scorm.api.LMSSetValue("cmi.core.score.raw", newScore);
            result = apiResult == "true";
        }
    }

    console.log("SCORM: Set Score - Result: " + result);

    return result;
}

function GetScore_CheckInitial() {
    console.log("SCORM: Get Score - Begin");

    var result = null;

    if (scorm.api) {
        if (version_2004) {
            result = scorm.api.GetValue("cmi.score.raw")
        } else {
            result = scorm.api.LMSGetValue("cmi.core.score.raw");
        }
    }

    console.log("SCORM: Get Score - Result: " + result);

    if (result != null && result !== "") {
        return parseFloat(result);
    } else {
        return -1;
    }
}

function GetScore() {
    console.log("SCORM: Get Score - Begin");

    var result = null;

    if (scorm.api && scormInitialized) {
        if (version_2004) {
            result = scorm.api.GetValue("cmi.score.raw")
        } else {
            result = scorm.api.LMSGetValue("cmi.core.score.raw");
        }
    }

    console.log("SCORM: Get Score - Result: " + result);

    if (result != null && result !== "") {
        return parseFloat(result);
    } else {
        return -1;
    }
}

function GetGameData() {
    var result = null;

    if (scorm.api && scormInitialized) {
        if (version_2004) {
            result = scorm.api.GetValue("cmi.suspend_data")
        } else {
            result = scorm.api.LMSGetValue("cmi.suspend_data");
        }
    }

    return result;
}

function SetGameData(data) {
    var result = false;

    if (scorm.api && scormInitialized) {
        if (version_2004) {
            var apiResult = scorm.api.SetValue("cmi.suspend_data", data)
            result = (apiResult == "true");
        } else {
            var apiResult = scorm.api.LMSSetValue("cmi.suspend_data", data);
            result = (apiResult == "true");
        }
    }

    return result;
}

function CommitChanges() {
    var result = false;

    if (scorm.api && scormInitialized) {
        if (version_2004) {
            var apiResult = scorm.api.Commit("")
            result = (apiResult == "true");
        } else {
            var apiResult = scorm.api.LMSCommit("");
            result = (apiResult == "true");
        }
    }

    if (result) {
        console.log("Commit Success");
    } else {
        console.error("Commit Failed");
    }

    return result;
}

function LMSTerminate() {
    var result = false;

    if (scorm.api && scormInitialized) {
        if (version_2004) {
            var apiResult = scorm.api.Terminate("");
            result = (apiResult == "true");
        } else {
            var apiResult = scorm.api.LMSFinish("");
            result = (apiResult == "true");
        }
    }

    if (result) {
        scormInitialized = false;
    }

    return result;
}

function LMSComplete(passed) {
    var result = false;


    if (scorm.api && scormInitialized) {
        if (version_2004) {
            var userPassed = passed ? "passed" : "failed";
            var result_completion = scorm.api.SetValue("cmi.completion_status", "completed");
            var result_success = scorm.api.SetValue("cmi.success_status", userPassed);
            result = (result_completion == "true" && result_success == "true");
        } else {
            var userPassed = passed ? "completed" : "incomplete";
            var apiResult = scorm.api.LMSSetValue("cmi.core.lesson_status", userPassed);
            result = apiResult == "true";
        }
    }

    return result;

}

function LMSFinish() {
    var result = false;

    if (scorm.api && scormInitialized) {
        if (version_2004) {
            result = scorm.api.Terminate("") == "true";
        } else {
            result = scorm.api.LMSFinish("") == "true";
        }
    }

    if (!result) {
        console.error("LMSFinish - Failed to Terminate Connection to LMS");
    } else {
        console.log("LMSFinish - Success Terminating SCORM Connection");
    }

    return result;
}

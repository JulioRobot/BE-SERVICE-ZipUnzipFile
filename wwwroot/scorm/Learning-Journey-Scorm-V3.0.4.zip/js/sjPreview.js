
var dotNetHomeRef;

window.addEventListener('message', function (event) {
    var message = event.data;
    console.log("Received Message: " + message);
    if (typeof (message) == "string") {
        dotNetHomeRef.invokeMethodAsync("ProcessParentMessage", message);
    }
});

function RegisterHomePage(dotNetRef) {
    dotNetHomeRef = dotNetRef;
    console.log("Registering dotnet obj");
}

function SendRequestMessage() {
    var message = "RequestLearningData";
    console.log("Sending Message: " + message);
    parent.postMessage(message, "*");
}

